from keras.models import Sequential
from keras.layers import Dense, Activation,GRU
from numpy import array


def predict_load(data):
    label=data

    label.append(label[len(label)-1])

    # Initializing the LSTM network
    model = Sequential()

    # Defining the cell type
    model.add(GRU(128, input_shape=(1, 1)))

    # Defining the densely connected Neural Network layer
    model.add(Dense(1))

    # Defining the activation function for the cell
    model.add(Activation('softmax'))


    # Configuring the model for training
    model.compile(loss='categorical_crossentropy', optimizer='adam')

    # return training data
    def get_train():
        seq = []
        for i in range(len(data)):
            tem = [data[i], label[i]]
            seq.append(tem)
        seq = array(seq)
        X, y = seq[:, 0], seq[:, 1]
        X = X.reshape((len(X), 1, 1))
        return X, y

    # fit model
    X, y = get_train()
    #tf.keras.utils.plot_model(model, to_file='GRU.png', show_shapes=True, show_layer_names=True)
    model.fit(X, y, batch_size = 128, epochs = 10,verbose=0)
    pred=model.predict(X)
    predicted = pred.flatten().tolist()

    return predicted[len(predicted) - 1]  # return the predicted load


