import random, numpy as np


def Migration_cost(assign, updated, p, s):
    summ_tc = 0
    for i in range(p):  # for each VM
        transmit = 0
        ind = np.where(np.array(assign) == (i + 1))[0]  # index of application in current VM
        for j in range(len(ind)):
            if assign[ind[j]] != updated[ind[j]]: transmit += 1  # increment if migration occurs
        summ_tc += transmit / s

    MC = summ_tc / p  # Migration cost formula
    return MC


def resource_utilization(soln_assign, u, m, b, f, p):
    summ, NF = 0, 10+random.random()    # NF => normalization factor
    for i in range(p):
        ind = np.where(np.array(soln_assign) == (i + 1))[0]  # index of application in current VM
        Nu, Nm, Nb, Nf = 0, 0, 0, 0
        if len(ind) > 0:  # appln. in VM
            for j in range(len(ind)):
                Nu += u[i][ind[j]]
                Nm += m[i][ind[j]]
                Nb += b[i][ind[j]]
                Nf += f[i][ind[j]]
            Nu, Nm, Nb, Nf = Nu / len(ind), Nm / len(ind), Nb / len(ind), Nf / len(ind)
            summ += ((Nu + Nm + Nb + Nf) / max(Nu, Nm, Nb, Nf))
    RU = (1 / p) * summ * (1 / NF)  # resource utilization formula
    return RU


def func(Lp,soln,init_assign,U, M, B, F, n_c,n_task):
    Fit=[]
    RU,MC=[],[]
    for i in range(len(soln)):

        res_util = resource_utilization(soln[i], U, M, B, F, n_c)  # resource utilization
        RU.append(res_util)

        cost = Migration_cost(init_assign, soln[i], n_c, n_task)  # Migration cost
        MC.append(cost)

        fit=(1/3)*(Lp+res_util+cost)
        Fit.append(fit)

    return Fit,RU