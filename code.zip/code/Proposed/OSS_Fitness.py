from Main import time_slot
import numpy as np

def func(soln,Task,runtime,n_user):
    Makespan=[]
    Fit=[]
    for i in range(len(soln)):
        F, Mak = time_slot.table(Task, runtime, n_user)  # Finish time & Makespan
        Makespan.append(Mak)
        fit=np.sum(Task[i])
        Fit.append(fit)
    return Fit,Makespan
