import random,math
import numpy as np
from Proposed import OSS_Fitness

def Algm(Task,runtime,n_user,n_pm,MAKESPAN):
    def generate(n, m, l, u):   #initial position
        data = []
        for i in range(n):
            tem = []
            for j in range(m):
                tem.append(random.uniform(l, u))
            data.append(tem)
        return data

    N, M, lb, ub = 10, n_pm, 0, 1
    g, max_iter = 0, 100

    soln = generate(N, M, lb, ub)
    MD = generate(N, M, lb, ub)


    # def fitness(soln):
    #     F = []
    #     for i in range(len(soln)):
    #         F.append(random.random())
    #     return F

    #phase 1
    def Exploration_phase(X,MD,f): # Choosing and Moving to the Migration Destination
        X1=[]
        r=random.uniform(0,1)
        I=random.randint(1,2)
        for i in range(len(X)):
            temp=[]
            for j in range(len(X[i])):

                temp.append((1/(2*np.cos(np.pi*max_iter))-1+I*r)*(X[i-1][j-1]*(1-2*np.cos(np.pi*max_iter))*(1-I*r)+r*MD[i][j]+(1+2*np.cos(np.pi*max_iter))))  # update equation
            X1.append(temp)
        fx1,Makespan=OSS_Fitness.func(X1,Task,runtime,n_user)
        XX=[]
        for i in range(len(X)):
            temp=[]
            for j in range(len(X[i])):
                if fx1[j]<=f[j]:
                    temp.append(X1[i][j])
                else:temp.append(X[i][j])
            XX.append(temp)

        return XX

    #phase 2
    #Adaptation to the New Environment in the Migration Destination
    def Exploitation_Phase(X,f):
        X2=[]
        for i in range(len(X)):
            temp=[]
            r = random.uniform(0, 1)
            for j in range(len(X[i])):
                temp.append(X[i][j]+(1-2*r)*(ub-lb)/max_iter)
            X2.append(temp)
        fx2,Makespan = OSS_Fitness.func(X2,Task,runtime,n_user)
        XX = []
        for i in range(len(X)):
            temp = []
            for j in range(len(X[i])):
                if fx2[j] <= f[j]:
                    temp.append(X2[i][j])
                else:
                    temp.append(X[i][j])
            XX.append(temp)
        return XX
    while g<max_iter:
        fit,Makespan = OSS_Fitness.func(soln,Task,runtime,n_user)
        bst=np.argmax(fit)
        X=Exploration_phase(soln,MD,fit)
        upd_soln=Exploitation_Phase(X,fit)
        bst_soln=upd_soln[bst]
        g += 1
    MAKESPAN.append(np.min(Makespan))

