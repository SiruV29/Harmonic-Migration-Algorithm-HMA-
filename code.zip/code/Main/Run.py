import Cloudsim.Run
import numpy as np
import Proposed.GRU
import Proposed.HMO
import Proposed.Optimal_switching_stategy
# assign the resources
def assign(sym, sub_sym):
    base_loc = []
    n, m = 1, int(sub_sym / sym)
    for i in range(sym):  # no.of PM
        if n < sym:  # if m = 5, then 1st 5 VM in PM 1, 2nd 5 in PM 2, so on..
            it = 0
            while it < m:
                base_loc.append(n)  # VM in which PM
                it += 1
            n += 1
        else:  # last 5 + remaining VM in last PM (if VM = 52 then 7 VM in last PM)
            it = len(base_loc) - 1
            while it < sub_sym - 1:
                base_loc.append(n)
                it += 1
    return base_loc
# load calculation
def load(soln_assign, Nu, Nm, Nb, Nf, p, s):
    summ, NF = 0, 100
    cal_Load=[]
    for q in range(s):  # for each application
        X = 0
        for i in range(p):
            if soln_assign[q] == (i+1): # if appln. in container
                X = 1

                # capacity of container in running qth application
                Cq = (Nu[i][q] + Nm[i][q] + Nb[i][q] + Nf[i][q]) / max(Nu[i][q], Nm[i][q], Nb[i][q], Nf[i][q])
                summ += Cq*X     # Load formula
                cal_Load.append(Cq*X)
    n = round(summ/NF)

    cal_Load=[np.abs(cal_Load[ii]/NF)-n for ii in range(len(cal_Load))]
    return cal_Load
def runtime_initialization(n_user, n_task):
    for i in range (n_task):
        tem = []
        for j in range (n_user-1):  # except requester
            tem.append(np.random.randint(1, m_runtime))    # random between 1 & max runtime
        runtime.append(tem)
    return runtime

def initialization(n_user, n_task):
    # communication duration & bandwidth for each user
    for i in range (n_user):
        comm_dur.append(np.random.random())  # random between 0 & 1
        bandwidth.append(np.random.random())
    runtime=runtime_initialization(n_user, n_task)
    return runtime
runtime, comm_dur, bandwidth = [], [], []
m_runtime = 5
def callmain(n_task):
    PL,MK,RU=[],[],[]

    PM = 10
    n_vm, n_cnr=20,50
    VM_assign = assign(PM, n_vm)  # assign VM to PM
    container_assign = assign(n_vm, n_cnr)  # assign container to VM
    Task_assign = assign(n_cnr, n_task)  # assign application to container
    n_user=500
    # VM Parameters
    print("\nInitializing VM parameters..")
    C, M, B, F = Cloudsim.Run.cloud_sim(n_vm, n_task)  # cpu, MIPS, bandwidth, frequency

    Load=load(VM_assign,C,M,B,F,n_vm,PM)

    Lp=Proposed.GRU.predict_load(Load)

    Th=0.5

    runtime = initialization(n_user, n_task)
    if Lp >Th:
        'VM Migration'
        Proposed.HMO.Algm(Lp,VM_assign,C, M, B, F, n_cnr,PM,n_task,RU)
    else:
        'Optimal switching statergy'
        Proposed.Optimal_switching_stategy.Algm(Task_assign,runtime,n_user,PM,MK)
    PL.append(Lp)
    return PL,MK,RU

