import random
def table(solution, runtime, n_user):

    timeslot = []
    task_finish_time = []

    S = 0      # number of time slot
    for i in range (0, len(runtime)):          # loop upto solution size
        user = int(solution[i]-2)               # user location
        user_runtime = runtime[i][user]         # runtime of the user
        task_finish_time.append(user_runtime)   # Finish time of each task
        for k in range(0, user_runtime):        # time slot for each task
            timeslot.append([])
            for j in range (0, n_user-1):  # except requester
                if (j == user):
                    timeslot[S].append(i+1)
                else:
                    timeslot[S].append(0)
            S += 1  # next time slot
    
    return task_finish_time, S
        
        